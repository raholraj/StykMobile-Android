# StykAnimate 1.2.5

Layer folders, camera follow and smoother editing

### Added

- Layer folders with quick creation and a searchable filter to organize your timeline.
- Playback ranges to loop a chosen section of your animation.
- Automatic updates for the Linux AppImage, with a prompt to save your work before restarting.
- Move a layer up or down from its menu in the timeline.
- Auto key in the Advanced timeline: turn it on (K) and every change you make adds a keyframe at the playhead.
- Camera follow: right-click figures and choose Follow with camera to keep them in frame, with smooth catch-up, look ahead, a dead zone and auto zoom. Projects that use it need this version or newer.

### Changed

- Shorter layer menus with related commands grouped into submenus.
- Easier timeline navigation: zooming stays on the playhead, the view follows it, and there is room below the last layer.
- Layer focus stays active until you turn it off, with support for multiple layers and Focus and lock to protect other artwork while you work.
- Zooming the canvas with the mouse wheel is smooth and easier to control. Compatibility mode zooms in quick steps by default, and Settings › Canvas › Smooth zooming lets you choose.
- Complete interface translations for all 26 supported non-English languages, with right-to-left layouts and clearer text in narrow windows.
- Onion skin is enabled when the app starts.
- While joining figures, movable nodes are shown in red and static nodes in white.
- A simpler Motion tab for camera moves, with a gallery that explains each preset and plain sliders for the settings that matter most.
- Dragging layers in the timeline shows where they will land, moves several layers or a whole folder at once, and drops them into or out of folders.
- Camera motions share one compact timeline row, color-coded by type, that only grows where motions overlap. Hover a motion to see its name and frames.
- Redesigned onion skin markers on the timeline: drag them straight to the frame you want, without catching the playhead. You can hide them in onion skin settings.

### Fixed

- Repeated Save commands no longer start overlapping writes, and newer edits keep the project open when closing.
- Successful saves no longer show a failure if an old recovery copy cannot be removed.
- Imported Pivot originals stay available after other imports, and saving stops if an original cannot be retrieved.
- Recovery copies are scheduled more reliably during frequent editing.
- Fixed multiple layer selections and searches being lost during editing.
- Fixed figures and text staying blurry when zooming far into the canvas.
- Fixed long freezes when zooming or panning animations that use effects or onion skins.
- Fixed blur, glow, and shadow effects shifting or failing at certain positions.
- Fixed drawings disappearing with VFX enabled or changing layer position after the first stroke.
- Fixed onion skins disappearing behind lower layers or skipping nearby drawings in animations with many layers.
- Fixed repeated captions in controls and panels when changing the interface language.
- Fixed Settings running off the edge of very narrow windows.
- Browser downloads now keep your work recoverable until a file save is confirmed.
- Browser recovery keeps each tab's unsaved project separately and pauses playback when the tab is hidden.
- Double-clicking a static node now selects its branch, just like other nodes.
- Clicking a frame in the Simple timeline keeps your current selection instead of selecting every figure.
- Copying, pasting or duplicating a figure now keeps its effects.
- Bending a connector now follows your pointer smoothly, and also works with Move joint in Build.
- Adding parts to a figure in an imported Stick Nodes project no longer stops the saved project from opening.

### Performance

- Smoother scrolling through long layer lists in the timeline.
- Quicker repeated saves for small projects and smaller exported movieclips.
- Smoother zooming and panning, fewer pauses, and more responsive joints and selection when editing complex animations in Compatibility mode.
- Much smoother playback of busy animations and scenes with effects, with fewer pauses, especially on laptops without a dedicated graphics card and in Compatibility mode.
- Complex STK figures open faster, including figures with long chains of joints.
- Faster color adjustments on large drawings, especially when painted areas are far apart.
- Faster keyframe edits and figure posing in long animations with many layers.
- Large personal libraries open faster, with more responsive selection.
- Quicker preparation for playback and exports.
- APNG and PNG sequence exports use less memory.

Free to create. Powered by your support.

StykAnimate is completely free. If it helps bring your ideas to life, a donation helps keep development moving. [Support development on Ko-fi](https://ko-fi.com/Q5Q41WY7QC).

Install the **Setup** version for automatic updates. Portable copies require manual updates.
